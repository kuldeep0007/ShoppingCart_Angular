export interface IProduct {
    productCategory: string;
    imageUrl: string;
}