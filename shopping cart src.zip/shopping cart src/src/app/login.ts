export class Login {
  uid: string;
  pass: string;
}
