import { Login } from './login';

export const LOGINS: Login[] = [
  { uid: 'admin', pass: 'admin' }
];
