export class IProduct{
    productId: string;
    productName: string;
    productPrice: number;
    productImg: string;
    productCategory:string;
}